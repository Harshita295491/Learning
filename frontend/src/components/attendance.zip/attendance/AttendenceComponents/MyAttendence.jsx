import React from 'react'

function MyAttendence() {
  return (

    <div >
       <div className="w-full p-5 ">
        {/* <h1 className="text-[30px] font-medium mb-6">Job Information</h1> */}
        <div className="w-[1000px] overflow-x-auto no-scrollbar overflow-auto">
          <table className="w-full border table-fixed text-[12px] border-gray-300 text-start">
            <thead>
              <tr className=" font-medium">
                <th className="w-[200px] px-2 py-2 text-start border border-gray-300">Working Hours</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Actual Working Time</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Tracked Hours</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Time Difference</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Attendence Action</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Payroll Present Days</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300"></th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Total Time</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Break Hours</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Productive Hours</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Extra Time</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Shift</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Job Title</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Department</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Clock OUT IP</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Action</th>

              </tr>
            </thead>
            <tbody>
              <tr>

                <td className="w-[200px] px-2 py-3 border border-gray-300">Wed 23 Oct, 2024</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">Vasavi Patnaik</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">no</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300"></td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">On Going</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">8:30 AM</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">General Shift</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">Junior Software Engineer</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">27.52.4.222</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300"></td>

              </tr>
             

            </tbody>
          </table>
        </div>
      </div>
      <div className="w-full p-5 h-[100vh]">
        {/* <h1 className="text-[30px] font-medium mb-6">Job Information</h1> */}
        <div className="w-[1000px] overflow-x-auto no-scrollbar overflow-auto">
          <table className="w-full border table-fixed text-[12px] border-gray-300 text-start">
            <thead>
              <tr className="bg-[#B9B9B9] font-medium">
                <th className="w-[200px] px-2 py-2 text-start border border-gray-300">Date</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Display Name</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Day Status</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Attendence Status</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Attendence Action</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Clock-IN</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Clock-OUT</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Total Time</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Break Hours</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Productive Hours</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Extra Time</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Shift</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Job Title</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Department</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Clock OUT IP</th>
                <th className="w-[200px] px-2 py-3 text-start border border-gray-300">Action</th>

              </tr>
            </thead>
            <tbody>
              <tr>

                <td className="w-[200px] px-2 py-3 border border-gray-300">Wed 23 Oct, 2024</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">Vasavi Patnaik</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">no</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300"></td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">On Going</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">8:30 AM</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">General Shift</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">Junior Software Engineer</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">27.52.4.222</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300"></td>

              </tr>
              <tr>

                <td className="w-[200px] px-2 py-3 border border-gray-300">Wed 23 Oct, 2024</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">Vasavi Patnaik</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">no</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300"></td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">On Going</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">8:30 AM</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">General Shift</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">Junior Software Engineer</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">27.52.4.222</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300">-</td>
                <td className="w-[200px] px-2 py-3 border border-gray-300"></td>

              </tr>

            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default MyAttendence;