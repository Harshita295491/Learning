import React from 'react'

function MyStatusReport() {
  return (
    <div>MyStatusReport</div>
  )
}

export default MyStatusReport