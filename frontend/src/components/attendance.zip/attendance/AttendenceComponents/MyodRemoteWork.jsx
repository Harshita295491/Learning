import React from 'react'

function MyodRemoteWork() {
  return (
    <div>MyodRemoteWork</div>
  )
}

export default MyodRemoteWork