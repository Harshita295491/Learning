import React from 'react'

function MyLatein() {
  return (
    <div>MyLatein</div>
  )
}

export default MyLatein;