import React from 'react'
import AttendenceNavigation from './AttendenceNavigation'
function Attendence() {
  return (
    <div className='w-full bg-slate-200'>
      <AttendenceNavigation/>
    </div>
  )
}

export default Attendence